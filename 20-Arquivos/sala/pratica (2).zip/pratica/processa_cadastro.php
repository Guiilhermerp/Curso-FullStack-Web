<?php

	echo('<pre>post:');
	print_r($_POST);
	echo('</pre>');
	echo('<pre>get:');
	print_r($_GET);
	echo('</pre>');
	die();

?>