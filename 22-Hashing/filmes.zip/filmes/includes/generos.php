<?php
	
	$generos = [];
	$generos[0] = 'Ação';
	$generos[1] = 'Animação';
	$generos[2] = 'Aventura';
	$generos[3] = 'Comédia';
	$generos[4] = 'Drama';
	$generos[5] = 'Terror';
	$generos[6] = 'Romance';